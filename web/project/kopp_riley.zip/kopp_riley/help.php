<!DOCTYPE html>
<html>
<header>

</header>

<head>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">

    <div id="menu">
        <div class="page">
            <a href="./index.php">Main</a>
        </div>
        <div class="page">
            <a href="./file_mgmt.php">Files</a>
        </div>
        <div class="page currentPage">
            Help
        </div>
    </div>
</head>

<body>
    <h1>Owner</h1>
    <p>Riley Kopp</p>
    <p>Tier 3 Complete</p>
    <p>Extension 1: (5pt) 'Pretty' (Ugly) Button</p>
    <p>Extension 2: (10pt) User Defined Grid Size</p>
    <h1>CSS</h1>
    <p>99% of my CSS is in style.css the other 1% is done in picture.js where the divs are created in the grid. </p>
   <h1>Use:</h1>
   <h2>Main</h2>
   <p>
   Main holds the actual pixel editor. The editor supports 3 colors: Black, White, and Green. The grid can be resized to any square between 2x2 and 75x75. To save a file, either provide a name in the filename box and press 'save'
   or just press 'save' and the program will auto assign a name on the server.  
    </p>
   <h2>File Management</h2>
   <p>File Management works exactly as assigned. No changes here.</p>
</body>

</html>